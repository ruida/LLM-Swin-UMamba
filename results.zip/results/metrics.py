import os
import numpy as np
import cv2
from medpy.metric import binary
from medpy.metric.binary import dc, jc, hd95, sensitivity, specificity

# Paths
gt_dir = "GT"
pred_dir = "swinumamba_predict"

# Get sorted file lists
gt_files = sorted([f for f in os.listdir(gt_dir) if f.endswith(".png")])
pred_files = sorted([f for f in os.listdir(pred_dir) if f.endswith(".png")])

assert gt_files == pred_files, "Mismatch in filenames between GT and predictions!"

# Metric containers
dice_scores = []
jaccard_scores = []
hausdorff_scores = []
sensitivity_scores = []
specificity_scores = []
valid_filenames = []  # Track valid cases (non-empty GT)

for fname in gt_files:
    gt = cv2.imread(os.path.join(gt_dir, fname), cv2.IMREAD_GRAYSCALE)
    pred = cv2.imread(os.path.join(pred_dir, fname), cv2.IMREAD_GRAYSCALE)

    # Binarize
    gt_bin = (gt > 0).astype(np.bool_)
    pred_bin = (pred > 0).astype(np.bool_)

    # Skip empty ground truth (optional)
    if not np.any(gt_bin):
        print(f"Skipping {fname}: empty GT.")
        continue

    try:
        dice_scores.append(dc(pred_bin, gt_bin))
        jaccard_scores.append(jc(pred_bin, gt_bin))
        hausdorff_scores.append(hd95(pred_bin, gt_bin))
        sensitivity_scores.append(sensitivity(pred_bin, gt_bin))
        specificity_scores.append(specificity(pred_bin, gt_bin))
        valid_filenames.append(fname)
    except Exception as e:
        print(f"{fname}: Metric computation failed: {e}")

# Compute mean & std
def summarize(name, values):
    values = np.array(values)
    print(f"{name:<15} Mean: {np.mean(values):.4f} | Std: {np.std(values):.4f}")

print("\n==== Evaluation Summary ====")
summarize("Dice", dice_scores)
summarize("Jaccard", jaccard_scores)
summarize("Hausdorff95", hausdorff_scores)
summarize("Sensitivity", sensitivity_scores)
summarize("Specificity", specificity_scores)

# Save Dice scores per case
with open("swinumamba_dice_per_case.txt", "w") as f:
    for fname, score in zip(valid_filenames, dice_scores):
        f.write(f"{fname}: {score:.4f}\n")

print("\nSaved per-case Dice scores to dice_per_case.txt")

