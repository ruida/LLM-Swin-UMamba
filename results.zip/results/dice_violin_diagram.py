import os
import re
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib as mpl

mpl.rcParams['font.family'] = 'serif'
mpl.rcParams['font.weight'] = 'bold'

# ---------- Function: Extract Dice from text file ----------
def extract_dice_from_txt(filepath):
    dice_scores = []
    with open(filepath, 'r') as f:
        for line in f:
            if ':' in line:
                try:
                    _, score = line.strip().split(":")
                    dice_scores.append(float(score.strip()))
                except ValueError:
                    continue
    return dice_scores

# ---------- Load Dice from all 4 files ----------
langGuide_dice = extract_dice_from_txt("lang_dice_per_case.txt")
xLSTM_dice = extract_dice_from_txt("xLSTM_dice_per_case.txt")
nnUNet_dice = extract_dice_from_txt("nnUNet_dice_per_case.txt")
swin_dice = extract_dice_from_txt("swinumamba_dice_per_case.txt")

# ---------- Prepare data for seaborn ----------
all_scores = (
    [("LanGuideMedSeg", v) for v in langGuide_dice] +
    [("xLSTM-UNET", v) for v in xLSTM_dice] +
    [("nnUNet", v) for v in nnUNet_dice] +
    [("LLM-Swin-UMamba", v) for v in swin_dice]
)

labels, values = zip(*all_scores)

# ---------- Plot violin ----------
plt.figure(figsize=(10, 6))
sns.violinplot(x=labels, y=values, palette=["navajowhite", "skyblue", "lightgreen", "plum"], inner="box")

plt.title("Dice Score Distribution Across Models", fontweight='bold')
# plt.xlabel("Model", fontweight='bold')
plt.ylabel("Dice Score", fontweight='bold')
plt.xticks(fontweight='bold')
plt.yticks(fontweight='bold')

plt.grid(True, axis="y")
plt.tight_layout()
plt.show()

